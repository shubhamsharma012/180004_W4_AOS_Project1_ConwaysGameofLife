package main.com.lifegame.interfaces;

public interface UpdateShell {
	public void update();
}
